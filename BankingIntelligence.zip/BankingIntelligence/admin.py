import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from auth import list_users, change_user_role, delete_user, signup
from document_processor import upload_document, list_documents, delete_document, get_document_stats
from database_json import get_user_stats, get_chat_stats, get_document_stats as get_db_document_stats
from chatbot import clear_knowledge_base

def admin_dashboard():
    """Admin dashboard with user management and document processing."""
    # Purple gradient header for admin dashboard
    st.markdown("""
    <div style='background: linear-gradient(90deg, rgba(156,39,176,0.2) 0%, rgba(103,58,183,0.1) 100%); 
                padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);'>
        <h1 style='margin:0; color: #BB86FC; font-size: 2rem;'>
            <span style='margin-right: 10px;'>💼</span> Admin Dashboard
        </h1>
        <p style='margin: 0.5rem 0 0 0; opacity: 0.8;'>
            Manage users, documents, and system settings
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if current user is admin
    if not st.session_state.authenticated or st.session_state.role != "admin":
        st.markdown("""
        <div style='background-color: rgba(211, 47, 47, 0.1); padding: 1rem; 
                   border-radius: 8px; border-left: 4px solid #D32F2F;'>
            <h3 style='margin: 0; color: #D32F2F; font-size: 1.2rem;'>Access Denied</h3>
            <p style='margin: 0.5rem 0 0 0;'>You don't have permission to access this page.</p>
        </div>
        """, unsafe_allow_html=True)
        return
    
    # Custom styled tabs
    st.markdown("""
    <style>
        .stTabs [data-baseweb="tab-list"] {
            gap: 8px;
        }
        
        .stTabs [data-baseweb="tab"] {
            background-color: rgba(45, 45, 68, 0.6);
            border-radius: 8px;
            padding: 8px 16px;
            color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .stTabs [aria-selected="true"] {
            background-color: rgba(156, 39, 176, 0.2);
            border-bottom: 2px solid #9C27B0;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Tabs for different admin functions with icons
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "👥 User Management",
        "📄 Document Upload", 
        "📚 Document Library", 
        "📊 System Analytics", 
        "⚙️ Model Settings"
    ])
    
    # Tab 1: User Management
    with tab1:
        st.header("User Management")
        
        # Create New User (only admins can do this)
        st.subheader("Create New User")
        with st.form("create_user_form"):
            new_username = st.text_input("Username")
            new_password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            new_user_role = st.selectbox("Role", ["user", "admin"])
            submit_create = st.form_submit_button("Create User")
            
            if submit_create:
                if not new_username or not new_password:
                    st.error("Username and password are required.")
                elif new_password != confirm_password:
                    st.error("Passwords do not match.")
                elif signup(new_username, new_password, role=new_user_role):
                    st.success(f"User '{new_username}' created successfully with role: {new_user_role}")
                else:
                    st.error("Failed to create user. Username may already exist.")
        
        st.divider()
        
        # Get user list
        users = list_users(st.session_state.username)
        
        if users:
            # Display users in a table
            user_df = pd.DataFrame(users)
            st.dataframe(user_df)
            
            # User role management
            st.subheader("Change User Role")
            with st.form("change_role_form"):
                selected_user = st.selectbox("Select User", [user["username"] for user in users])
                new_role = st.selectbox("New Role", ["admin", "user"])
                submit_role = st.form_submit_button("Change Role")
                
                if submit_role:
                    if selected_user == st.session_state.username and new_role != "admin":
                        st.error("You cannot demote yourself from admin.")
                    elif change_user_role(selected_user, new_role, st.session_state.username):
                        st.success(f"Changed role of {selected_user} to {new_role}.")
                    else:
                        st.error("Failed to change user role.")
            
            # User deletion
            st.subheader("Delete User")
            with st.form("delete_user_form"):
                selected_user_del = st.selectbox("Select User to Delete", [user["username"] for user in users if user["username"] != st.session_state.username])
                submit_del = st.form_submit_button("Delete User")
                
                if submit_del:
                    if delete_user(selected_user_del, st.session_state.username):
                        st.success(f"Deleted user {selected_user_del}.")
                    else:
                        st.error("Failed to delete user.")
        else:
            st.warning("No users found or you don't have permission to view users.")
    
    # Tab 2: Document Upload
    with tab2:
        st.header("Document Upload")
        
        with st.form("upload_form"):
            st.info("Only PDF and TXT files are supported")
            uploaded_file = st.file_uploader("Choose a file", type=["pdf", "txt"])
            file_type = st.selectbox("File Type", ["pdf", "txt"])
            description = st.text_area("Description", "Enter a description of the document...")
            submit_upload = st.form_submit_button("Upload Document")
            
            if submit_upload:
                if uploaded_file:
                    success, message = upload_document(uploaded_file, file_type, description, st.session_state.username)
                    if success:
                        st.success(message)
                    else:
                        st.error(message)
                else:
                    st.error("Please select a file to upload.")
    
    # Tab 3: Document Management
    with tab3:
        st.header("Document Management")
        
        # Get document list
        documents = list_documents()
        
        if documents:
            # Display documents in a table
            doc_data = []
            for i, doc in enumerate(documents):
                doc_data.append({
                    "ID": i,
                    "Filename": doc["filename"],
                    "Type": doc["file_type"],
                    "Chunks": doc.get("chunks", "N/A"),
                    "Uploaded By": doc.get("uploaded_by", "Unknown"),
                    "Description": doc.get("description", "")[:50] + ("..." if len(doc.get("description", "")) > 50 else "")
                })
            
            doc_df = pd.DataFrame(doc_data)
            st.dataframe(doc_df)
            
            # Document deletion
            st.subheader("Delete Document")
            with st.form("delete_doc_form"):
                selected_doc = st.selectbox("Select Document to Delete", 
                                            range(len(documents)), 
                                            format_func=lambda x: f"{documents[x]['filename']} (ID: {x})")
                submit_doc_del = st.form_submit_button("Delete Document")
                
                if submit_doc_del:
                    success, message = delete_document(selected_doc)
                    if success:
                        st.success(message)
                    else:
                        st.error(message)
        else:
            st.info("No documents have been uploaded yet.")
    
    # Tab 4: System Stats
    with tab4:
        st.header("System Statistics")
        
        # Get stats
        user_stats = get_user_stats()
        doc_stats = get_document_stats()
        
        # Display user stats
        st.subheader("User Statistics")
        st.write(f"Total Users: {user_stats['total_users']}")
        
        # Some stats might not be available yet
        if 'users_with_chat_history' in user_stats:
            st.write(f"Users with Chat History: {user_stats['users_with_chat_history']}")
        
        if 'total_messages' in user_stats:
            st.write(f"Total Messages: {user_stats['total_messages']}")
        
        # Users by role chart
        if 'user_roles' in user_stats and user_stats['user_roles']:
            fig, ax = plt.subplots()
            ax.bar(user_stats['user_roles'].keys(), user_stats['user_roles'].values())
            ax.set_title('Users by Role')
            ax.set_xlabel('Role')
            ax.set_ylabel('Count')
            st.pyplot(fig)
        
        # Display document stats
        st.subheader("Document Statistics")
        if 'total_documents' in doc_stats:
            st.write(f"Total Documents: {doc_stats['total_documents']}")
        if 'total_chunks' in doc_stats:
            st.write(f"Total Chunks: {doc_stats['total_chunks']}")
        
        # Documents by file type chart
        if 'by_file_type' in doc_stats and doc_stats['by_file_type']:
            fig, ax = plt.subplots()
            ax.bar(doc_stats['by_file_type'].keys(), doc_stats['by_file_type'].values())
            ax.set_title('Documents by File Type')
            ax.set_xlabel('File Type')
            ax.set_ylabel('Count')
            st.pyplot(fig)
        
        # No need for backup since we're already using JSON files
        st.subheader("Database Information")
        st.info("The application is using JSON files for data storage, which are automatically saved in the data directory.")
    
    # Tab 5: Model Management
    with tab5:
        st.header("TinyLlama Model Management")
        
        st.subheader("Clear Knowledge Base")
        st.warning("⚠️ WARNING: This will completely reset the model's knowledge base and start training from scratch.")
        st.info("Use this option when you want to rebuild the model without any pre-filled information.")
        
        with st.form("clear_kb_form"):
            confirmation = st.text_input("Type 'RESET' to confirm clearing the knowledge base:")
            submit_reset = st.form_submit_button("Reset Knowledge Base")
            
            if submit_reset:
                if confirmation == "RESET":
                    message = clear_knowledge_base()
                    st.success(message)
                    st.info("Upload new documents to begin training the model from scratch.")
                else:
                    st.error("Please type 'RESET' to confirm this action.")
