import streamlit as st
import os
import numpy as np
import pickle
import tempfile
import re
import time
import nltk
import torch
import torch.nn as nn
import torch.optim as optim
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
# Import JSON database functions for chat history
from database_json import add_chat_message, get_chat_history, clear_chat_history

# Download required NLTK data
nltk.download('punkt', quiet=True)
nltk.download('wordnet', quiet=True)
nltk.download('stopwords', quiet=True)
from nltk.stem import WordNetLemmatizer

# Simple TinyLLama-inspired model using PyTorch
class TinyLlamaModel(nn.Module):
    def __init__(self, input_size, hidden_size=64, output_size=64):
        super(TinyLlamaModel, self).__init__()
        self.hidden_size = hidden_size
        
        # Simple feed-forward network
        self.encoder = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Linear(hidden_size // 2, output_size),
        )
        
    def forward(self, x):
        return self.encoder(x)

class TinyModelChatbot:
    def __init__(self, vector_size=100):
        """Initialize the TinyModel chatbot with vector size."""
        self.vector_size = vector_size
        self.lemmatizer = WordNetLemmatizer()
        self.documents = []
        self.document_vectors = None
        self.faiss_index = None
        
        # Use TF-IDF vectorizer for text representation
        self.tfidf_vectorizer = TfidfVectorizer(
            min_df=1, 
            stop_words='english',
            lowercase=True,
            tokenizer=self.custom_tokenizer,
            max_features=self.vector_size  # Limit to vector size
        )
        
        # Create TinyLlama model instance
        self.model = TinyLlamaModel(
            input_size=self.vector_size,
            hidden_size=64,
            output_size=64
        )
        
        # Optimizer for the model
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        
        # Initialize model with random values for similarity
        self.model_initialized = False
        
    def custom_tokenizer(self, text):
        """Custom tokenizer that lemmatizes text."""
        # Use simple split by spaces for tokenization
        tokens = text.lower().split()
        # Remove punctuation from tokens
        tokens = [re.sub(r'[^\w\s]', '', token) for token in tokens]
        # Filter out empty tokens
        tokens = [token for token in tokens if token]
        # Lemmatize the tokens
        lemmatized_tokens = [self.lemmatizer.lemmatize(token) for token in tokens]
        return lemmatized_tokens
    
    def preprocess_text(self, text):
        """Preprocess text by removing special characters and extra spaces."""
        text = re.sub(r'[^\w\s]', ' ', text)  # Remove special characters
        text = re.sub(r'\s+', ' ', text)      # Remove extra spaces
        return text.strip().lower()
    
    def add_documents(self, documents):
        """Add documents to the knowledge base using FAISS for vector storage."""
        if not documents:
            return 0
            
        # Store original documents
        old_doc_count = len(self.documents)
        self.documents.extend(documents)
        
        # Preprocess documents
        all_texts = []
        for doc in self.documents:
            content = doc["page_content"]
            processed_text = self.preprocess_text(content)
            all_texts.append(processed_text)
        
        # Fit TF-IDF vectorizer on all documents
        self.tfidf_vectorizer.fit(all_texts)
        
        # Generate document vectors for all documents
        self.document_vectors = self.tfidf_vectorizer.transform(all_texts)
        
        # Update FAISS index with new vectors
        # We need to recreate the index because the dimensions might have changed with new vocabulary
        dense_vectors = self.document_vectors.toarray().astype(np.float32)
        dimension = dense_vectors.shape[1]
        
        # Create new FAISS index
        self.faiss_index = faiss.IndexFlatL2(dimension)
        
        # Add all vectors to the index
        self.faiss_index.add(dense_vectors)
        print(f"FAISS index updated with {len(self.documents)} documents (added {len(documents)} new)")
        
        # Initialize the model if we have enough documents
        if len(self.documents) >= 5 and not self.model_initialized:
            self._initialize_model()
        
        return len(documents)
    
    def _initialize_model(self):
        """Initialize the model with dummy data if needed."""
        try:
            # Get the actual feature size from the vectorizer
            actual_features = len(self.tfidf_vectorizer.get_feature_names_out())
            print(f"Actual TF-IDF features: {actual_features}")
            
            # Recreate the model with the correct input dimension
            self.model = TinyLlamaModel(
                input_size=actual_features,
                hidden_size=64,
                output_size=64
            )
            
            # Recreate optimizer
            self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
            
            # Set model to training mode
            self.model.train()
            
            # Check if document_vectors is initialized
            if self.document_vectors is None:
                # Create random vectors if no documents are available
                X = np.random.rand(10, actual_features).astype(np.float32)
            else:
                # Use actual document vectors if available
                X = self.document_vectors.toarray()[:10].astype(np.float32)
                if len(X) < 5:  # Need at least a few samples
                    X = np.random.rand(10, actual_features).astype(np.float32)
            
            # Create dummy targets (similar/not similar pairs)
            y = np.random.randint(0, 2, X.shape[0]).astype(np.float32)
            
            # Convert to torch tensors
            X_tensor = torch.tensor(X)
            y_tensor = torch.tensor(y).view(-1, 1)
            
            # Simple training loop
            for epoch in range(5):  # Just a few epochs for initialization
                # Forward pass
                self.optimizer.zero_grad()
                outputs = self.model(X_tensor)
                
                # Just a simple loss function for demonstration
                loss = torch.mean((outputs[:, 0] - y_tensor[:, 0]) ** 2)
                
                # Backward and optimize
                loss.backward()
                self.optimizer.step()
            
            # Set model back to evaluation mode
            self.model.eval()
            self.model_initialized = True
            print("Model initialization successful!")
            
        except Exception as e:
            print(f"Error initializing model: {e}")
    
    def search_documents(self, query, top_k=5):
        """Search for documents relevant to the query using FAISS and TinyLlama model."""
        if not self.documents or self.document_vectors is None:
            return []
            
        # Preprocess the query
        processed_query = self.preprocess_text(query)
        
        # Vectorize the query
        query_vector = self.tfidf_vectorizer.transform([processed_query])
        
        # Initialize or update FAISS index if needed
        if self.faiss_index is None:
            # Convert sparse matrix to dense
            dense_vectors = self.document_vectors.toarray().astype(np.float32)
            # Get dimension from vectors
            dimension = dense_vectors.shape[1]
            # Create FAISS index - use L2 distance for simplicity
            self.faiss_index = faiss.IndexFlatL2(dimension)
            # Add vectors to the index
            self.faiss_index.add(dense_vectors)
            print(f"FAISS index created with {len(self.documents)} documents")
        
        # Convert query to dense vector
        query_dense = query_vector.toarray().astype(np.float32)
        
        # Search the FAISS index
        distances, indices = self.faiss_index.search(query_dense, min(top_k * 2, len(self.documents)))
        
        # Filter out invalid indices (FAISS might return -1 if not enough results)
        candidate_indices = [idx for idx in indices[0] if idx >= 0]
        
        # If model is initialized, use it to refine rankings
        if self.model_initialized and len(candidate_indices) > 0:
            try:
                # Set model to evaluation mode
                self.model.eval()
                
                # Convert query vector to tensor
                query_tensor = torch.tensor(query_vector.toarray().astype(np.float32))
                
                # Get document vectors for candidates
                doc_vectors = self.document_vectors[candidate_indices].toarray().astype(np.float32)
                doc_tensors = torch.tensor(doc_vectors)
                
                # Encode query and documents with the model
                with torch.no_grad():
                    query_encoding = self.model(query_tensor)
                    doc_encodings = self.model(doc_tensors)
                
                # Calculate cosine similarity between query and documents
                model_similarities = torch.nn.functional.cosine_similarity(
                    query_encoding, doc_encodings
                ).numpy()
                
                # Get TF-IDF similarities for these candidates
                tfidf_similarities = cosine_similarity(
                    query_vector, self.document_vectors[candidate_indices]
                ).flatten()
                
                # Combine FAISS similarity with model similarity
                combined_similarities = []
                for i, idx in enumerate(candidate_indices):
                    faiss_sim = 1.0 / (1.0 + distances[0][i])  # Convert distance to similarity
                    tfidf_sim = float(tfidf_similarities[i])
                    model_sim = float(model_similarities[i])
                    # Weighted combination
                    combined_sim = (0.4 * faiss_sim) + (0.3 * tfidf_sim) + (0.3 * model_sim)
                    combined_similarities.append((idx, combined_sim))
                
                # Sort by combined similarity
                combined_similarities.sort(key=lambda x: x[1], reverse=True)
                
                # Get top results
                results = []
                for idx, sim in combined_similarities[:top_k]:
                    if sim > 0.0:  # Only include if similarity > 0
                        results.append({
                            "document": self.documents[idx],
                            "similarity": float(sim)
                        })
                
                return results
                
            except Exception as e:
                print(f"Error using model for search: {e}")
                # Fall back to basic similarity if there's an error
        
        # If model not initialized or there was an error, fall back to basic FAISS similarity
        results = []
        for i, idx in enumerate(candidate_indices[:top_k]):
            # Convert distance to similarity score (closer to 0 is better for L2)
            similarity = 1.0 / (1.0 + distances[0][i])
            if similarity > 0.0:
                results.append({
                    "document": self.documents[idx],
                    "similarity": float(similarity)
                })
        
        return results
    
    def generate_response(self, query, chat_history=None):
        """Generate a response based on the query and relevant documents."""
        if not self.documents or self.document_vectors is None:
            return "My knowledge base is empty. Please use the admin interface to add training documents to help me learn."
        
        # Search for relevant documents
        relevant_docs = self.search_documents(query, top_k=5)
        
        if not relevant_docs:
            # Special message for empty knowledge base training mode
            if len(self.documents) < 3:
                return "I'm in training mode and don't have enough knowledge yet. Please add more documents through the admin interface to help me learn and respond better."
            return "I couldn't find any information related to your question. Try adding more specific training data or rephrase your question."
        
        # Extract content from relevant documents
        relevant_content = []
        for doc in relevant_docs:
            content = doc["document"]["page_content"]
            similarity = doc["similarity"]
            # Lower similarity threshold for training mode
            threshold = 0.05 if len(self.documents) < 10 else 0.1
            if similarity > threshold:
                relevant_content.append(content)
        
        if not relevant_content:
            return "I found some potentially relevant information, but I'm not confident enough in my answer. Please add more specific training data to help me understand this topic better."
        
        # Generate answer
        answer = self._formulate_answer(query, relevant_content, chat_history)
        return answer
    
    def _formulate_answer(self, query, relevant_content, chat_history=None):
        """Formulate an answer based on the query and relevant content using TinyLlama model."""
        try:
            # Check if model is initialized to use enhanced ranking
            if self.model_initialized and len(relevant_content) > 1:
                # Set model to evaluation mode
                self.model.eval()
                
                # Vectorize query for encoding
                query_vector = self.tfidf_vectorizer.transform([query]).toarray().astype(np.float32)
                query_tensor = torch.tensor(query_vector)
                
                # Encode query with the model
                with torch.no_grad():
                    query_encoding = self.model(query_tensor)
                
                # Encode each content piece and calculate similarity with query
                content_rankings = []
                for content in relevant_content:
                    # Vectorize content
                    content_vector = self.tfidf_vectorizer.transform([content]).toarray().astype(np.float32)
                    content_tensor = torch.tensor(content_vector)
                    
                    # Encode content
                    with torch.no_grad():
                        content_encoding = self.model(content_tensor)
                    
                    # Calculate similarity
                    similarity = torch.nn.functional.cosine_similarity(
                        query_encoding, content_encoding
                    ).item()
                    
                    content_rankings.append((content, similarity))
                
                # Sort by similarity (highest first)
                content_rankings.sort(key=lambda x: x[1], reverse=True)
                
                # Format response with the most relevant content first
                response = "Here's what I found based on my training data:\n\n"
                
                # Deduplicate and add contents in order of relevance
                unique_content = set()
                for content, similarity in content_rankings:
                    # Use first 100 chars as a rough deduplication key
                    key = content[:100]
                    if key not in unique_content:
                        unique_content.add(key)
                        # Only include confidence score during training mode (when less than 20 docs)
                        if len(self.documents) < 20:
                            conf_percent = int(similarity * 100)
                            response += f"• {content} (confidence: {conf_percent}%)\n\n"
                        else:
                            response += f"• {content}\n\n"
                
                return response.strip()
                
        except Exception as e:
            print(f"Error in formulating answer with model: {e}")
            # Fall back to basic answer formulation
        
        # Format response based on content (fallback method)
        if len(relevant_content) == 1:
            return relevant_content[0]
        else:
            # Combine information from multiple sources
            response = "Based on my training data, I found this information:\n\n"
            
            # Deduplicate similar content
            unique_content = set()
            for content in relevant_content:
                # Use first 100 chars as a rough deduplication key
                key = content[:100]
                if key not in unique_content:
                    unique_content.add(key)
                    response += f"• {content}\n\n"
            
            return response.strip()
        
# Global chatbot instance
chatbot = None

def initialize_chatbot():
    """Initialize the chatbot with the knowledge base."""
    global chatbot
    
    # Create the chatbot instance if it doesn't exist
    if chatbot is None:
        chatbot = TinyModelChatbot(vector_size=100)  # Initialize with vector size
    
    if os.path.exists("data/knowledge_base.pkl"):
        try:
            with open("data/knowledge_base.pkl", "rb") as f:
                documents = pickle.load(f)
                chatbot.add_documents(documents)
        except Exception as e:
            st.error(f"Error loading knowledge base: {e}")
            create_empty_knowledge_base()
    else:
        create_empty_knowledge_base()
    
    # Load chat history for current user if authenticated
    if st.session_state.authenticated and st.session_state.username:
        user_chat_history = get_chat_history(st.session_state.username)
        if user_chat_history:
            st.session_state.chat_history = user_chat_history

def create_empty_knowledge_base():
    """Create a truly empty knowledge base for training from scratch."""
    global chatbot
    
    # Create chatbot if it doesn't exist
    if chatbot is None:
        chatbot = TinyModelChatbot(vector_size=100)
    
    # Create an empty list of documents - no pre-filled knowledge
    documents = []
    
    # Save empty knowledge base
    os.makedirs("data", exist_ok=True)
    with open("data/knowledge_base.pkl", "wb") as f:
        pickle.dump(documents, f)
        
    print("Created empty knowledge base - ready for training from scratch")

def get_chatbot_response(query):
    """Get a response from the chatbot."""
    global chatbot
    
    # Initialize chatbot if not done already
    if chatbot is None:
        initialize_chatbot()
    
    # Generate response
    try:
        response = chatbot.generate_response(query, st.session_state.chat_history)
        
        # Save chat history for the current user
        if st.session_state.authenticated and st.session_state.username:
            # Add this chat message to the database
            add_chat_message(
                username=st.session_state.username,
                user_message=query,
                bot_response=response
            )
        
        return response
    except Exception as e:
        return f"I'm sorry, I encountered an error: {str(e)}. Please try again."

def add_document_to_vector_store(document_text, metadata):
    """Add a document to the knowledge base."""
    global chatbot
    
    # Initialize chatbot if not done already
    if chatbot is None:
        initialize_chatbot()
    
    # Split text into chunks (much simpler than before)
    chunk_size = 1000
    overlap = 200
    
    chunks = []
    for i in range(0, len(document_text), chunk_size - overlap):
        chunk = document_text[i:i + chunk_size]
        if len(chunk) >= 100:  # Only add chunks with meaningful content
            chunks.append(chunk)
    
    # Create documents from chunks
    documents = [{"page_content": chunk, "metadata": metadata} for chunk in chunks]
    
    # Add documents to chatbot
    chatbot.add_documents(documents)
    
    # Update knowledge base file
    if os.path.exists("data/knowledge_base.pkl"):
        try:
            with open("data/knowledge_base.pkl", "rb") as f:
                existing_documents = pickle.load(f)
            existing_documents.extend(documents)
            with open("data/knowledge_base.pkl", "wb") as f:
                pickle.dump(existing_documents, f)
        except Exception as e:
            # If there's an error, just save the current documents
            with open("data/knowledge_base.pkl", "wb") as f:
                pickle.dump(documents, f)
    else:
        with open("data/knowledge_base.pkl", "wb") as f:
            pickle.dump(documents, f)
    
    return len(chunks)

def reset_chat_history():
    """Reset the chat history."""
    st.session_state.chat_history = []
    
    # Clear chat history for the current user
    if st.session_state.authenticated and st.session_state.username:
        clear_chat_history(st.session_state.username)

def clear_knowledge_base():
    """Completely clear the knowledge base to start fresh."""
    global chatbot
    
    # Create a truly empty knowledge base
    create_empty_knowledge_base()
    
    # Reset the chatbot
    chatbot = TinyModelChatbot(vector_size=100)
    
    # Reset chat history
    reset_chat_history()
    
    return "Knowledge base has been reset. The chatbot is now ready to learn from scratch."
