import streamlit as st
import os
import json
import base64
from auth import login, signup, create_admin_if_not_exists, is_authenticated, logout, get_user_role
from chatbot import get_chatbot_response, initialize_chatbot, reset_chat_history, clear_knowledge_base
from document_processor import upload_document, list_documents
from admin import admin_dashboard
from database_json import initialize_database

# Page configuration
st.set_page_config(
    page_title="Bank Guidelines & Principles Assistant",
    page_icon="🏦",
    layout="centered",
    initial_sidebar_state="expanded",
)

# Custom CSS to enhance UI
def add_custom_css():
    css = """
    <style>
        /* Main container styling */
        .main .block-container {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }
        
        /* Card-like containers */
        div[data-testid="stForm"] {
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(156, 39, 176, 0.2);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background-color: rgba(45, 45, 68, 0.7);
            backdrop-filter: blur(10px);
            transition: transform 0.3s;
        }
        
        div[data-testid="stForm"]:hover {
            transform: translateY(-5px);
        }
        
        /* Chat message styling */
        div.stChatMessage {
            border-radius: 15px;
            margin-bottom: 0.75rem;
            padding: 0.5rem 1rem;
            border-color: #9C27B0;
        }
        
        div.stChatMessage[data-testid="stChatMessageContent"] {
            background-color: rgba(45, 45, 68, 0.7);
        }
        
        /* Button styling */
        .stButton button {
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .stButton button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(156, 39, 176, 0.3);
        }
        
        /* Header styling */
        h1, h2, h3 {
            color: #BB86FC !important;
            font-weight: 600 !important;
        }
        
        /* Sidebar improvements */
        section[data-testid="stSidebar"] .block-container {
            background-color: rgba(35, 35, 60, 0.7);
            backdrop-filter: blur(10px);
            padding: 2rem 1rem;
        }
        
        /* Custom divider */
        hr {
            border-color: rgba(156, 39, 176, 0.3);
            margin: 1.5rem 0;
        }
        
        /* Input field styling */
        div[data-testid="stTextInput"] input, 
        div[data-testid="stTextArea"] textarea {
            border-radius: 8px;
            border: 1px solid rgba(156, 39, 176, 0.3);
            padding: 0.5rem 1rem;
            background-color: rgba(30, 30, 47, 0.8);
        }
        
        div[data-testid="stTextInput"] input:focus, 
        div[data-testid="stTextArea"] textarea:focus {
            border-color: #9C27B0;
            box-shadow: 0 0 0 2px rgba(156, 39, 176, 0.2);
        }
        
        /* Success/Error message styling */
        div[data-testid="stAlert"] {
            border-radius: 8px;
            padding: 1rem;
            margin: 1rem 0;
        }
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

# Function to encode image as base64
def get_image_base64(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode()

# Add hero section with bank logo
def add_hero_section():
    hero_html = """
    <div style="display: flex; align-items: center; margin-bottom: 2rem; 
               background: linear-gradient(90deg, rgba(156,39,176,0.2) 0%, rgba(66,39,90,0.1) 100%); 
               padding: 1.5rem; border-radius: 15px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
        <div style="margin-right: 1.5rem;">
            <img src="data:image/png;base64,{}" style="width: 80px; height: 80px;" />
        </div>
        <div>
            <h1 style="margin: 0; font-size: 2.2rem; color: #BB86FC;">Bank Guidelines & Principles Assistant</h1>
            <p style="margin: 0.5rem 0 0 0; opacity: 0.8; font-size: 1.1rem;">
                Your AI guide to banking policies, regulations, and best practices
            </p>
        </div>
    </div>
    """
    
    # Use the existing icon or a default if it doesn't exist
    try:
        logo_base64 = get_image_base64("generated-icon.png")
        st.markdown(hero_html.format(logo_base64), unsafe_allow_html=True)
    except:
        # If icon file doesn't exist, skip the image part
        st.title("🏦 Bank Guidelines & Principles Assistant")
        st.markdown("<p style='opacity: 0.8; font-size: 1.1rem; margin-bottom: 2rem;'>Your AI guide to banking policies, regulations, and best practices</p>", unsafe_allow_html=True)

# Initialize session states if not already done
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'username' not in st.session_state:
    st.session_state.username = None
if 'role' not in st.session_state:
    st.session_state.role = None
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'chatbot_initialized' not in st.session_state:
    st.session_state.chatbot_initialized = False

# Initialize the database and create admin user if not exists
try:
    initialize_database()
    create_admin_if_not_exists()
except Exception as e:
    st.error(f"Database initialization error: {str(e)}")
    # Continue anyway to allow the app to load

# Initialize the chatbot if not already done
if not st.session_state.chatbot_initialized:
    initialize_chatbot()
    st.session_state.chatbot_initialized = True

# Main function
def main():
    # Apply custom CSS
    add_custom_css()
    
    # Sidebar
    with st.sidebar:
        st.image("generated-icon.png", width=100)
        st.title("Bank Guidelines Assistant")
        
        # Authentication section
        if not st.session_state.authenticated:
            login_form()
            
            # Help info for login
            with st.expander("ℹ️ Need Help?"):
                st.markdown("""
                **Default Admin Login:**
                - Username: `admin`
                - Password: `admin123`
                
                For security, please change the default admin password after first login.
                """)
        else:
            st.markdown(f"""
            <div style='background-color: rgba(156, 39, 176, 0.1); padding: 1rem; border-radius: 10px; margin-bottom: 1rem;'>
                <p style='margin:0; font-weight: 600; color: #BB86FC;'>👤 {st.session_state.username}</p>
                <p style='margin:0; font-size: 0.9rem; opacity: 0.8;'>Role: {st.session_state.role}</p>
            </div>
            """, unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🚪 Logout", use_container_width=True):
                    logout()
                    st.rerun()
            
            with col2:
                if st.button("🔄 Reset Chat", use_container_width=True):
                    reset_chat_history()
                    st.rerun()
            
            # Admin section
            if st.session_state.role == "admin":
                st.markdown("<hr>", unsafe_allow_html=True)
                st.subheader("💼 Admin Tools")
                
                # Admin action buttons with icons
                admin_col1, admin_col2 = st.columns(2)
                with admin_col1:
                    if st.button("🔧 Dashboard", use_container_width=True):
                        st.session_state.page = "admin_dashboard"
                
                with admin_col2:
                    if st.button("🧹 Reset KB", help="Completely reset the knowledge base", use_container_width=True):
                        result = clear_knowledge_base()
                        st.success(result)
                        st.session_state.chatbot_initialized = True
                        st.rerun()
                
                # System status indicator
                st.markdown("<hr>", unsafe_allow_html=True)
                st.markdown("""
                <div style='background-color: rgba(46, 125, 50, 0.1); padding: 0.7rem; border-radius: 8px; margin-top: 1rem;'>
                    <p style='margin:0; display: flex; align-items: center;'>
                        <span style='color: #4CAF50; font-size: 1.2rem; margin-right: 0.5rem;'>●</span> 
                        <span>System online</span>
                    </p>
                </div>
                """, unsafe_allow_html=True)

    # Main content
    if not st.session_state.authenticated:
        # Add hero section
        add_hero_section()
        
        st.markdown("""
        <div style='background-color: rgba(45, 45, 68, 0.7); padding: 2rem; border-radius: 15px; 
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); margin: 1rem 0;'>
            <h2 style='color: #BB86FC; margin-top: 0;'>Welcome to Your Bank Guidelines & Principles Assistant</h2>
            <p style='font-size: 1.1rem; opacity: 0.9;'>
                Your intelligent AI companion for navigating banking regulations, policies, and best practices.
            </p>
            <p style='opacity: 0.8;'>
                Please login using the sidebar to access the guidelines assistant. New accounts can only be created by administrators.
            </p>
            
            <div style='display: flex; margin-top: 2rem;'>
                <div style='flex: 1; text-align: center; padding: 1rem;'>
                    <span style='font-size: 2rem; color: #9C27B0;'>📜</span>
                    <h3 style='margin: 0.5rem 0; color: #BB86FC;'>Comprehensive</h3>
                    <p style='opacity: 0.8; font-size: 0.9rem;'>Complete coverage of banking policies and procedures</p>
                </div>
                <div style='flex: 1; text-align: center; padding: 1rem;'>
                    <span style='font-size: 2rem; color: #9C27B0;'>⚖️</span>
                    <h3 style='margin: 0.5rem 0; color: #BB86FC;'>Regulatory</h3>
                    <p style='opacity: 0.8; font-size: 0.9rem;'>Up-to-date information on banking regulations</p>
                </div>
                <div style='flex: 1; text-align: center; padding: 1rem;'>
                    <span style='font-size: 2rem; color: #9C27B0;'>🔍</span>
                    <h3 style='margin: 0.5rem 0; color: #BB86FC;'>Precise</h3>
                    <p style='opacity: 0.8; font-size: 0.9rem;'>Clear guidance on banking standards and protocols</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        # Check which page to display
        if st.session_state.get('page') == "admin_dashboard" and st.session_state.role == "admin":
            admin_dashboard()
        else:
            chat_interface()

def login_form():
    st.markdown("""
    <div style='padding: 0.5rem 0; margin-bottom: 1rem;'>
        <h3 style='font-size: 1.3rem; margin-bottom: 0.8rem; color: #BB86FC;'>👋 Welcome Back</h3>
        <p style='font-size: 0.9rem; opacity: 0.8; margin-bottom: 1rem;'>
            Please enter your credentials to access the bank guidelines assistant.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    with st.form("login_form"):
        username = st.text_input("Username", placeholder="Enter your username")
        password = st.text_input("Password", type="password", placeholder="Enter your password")
        
        submit_col1, submit_col2 = st.columns([3, 1])
        with submit_col1:
            submit = st.form_submit_button("🔐 Sign In", use_container_width=True)
        
        if submit:
            if login(username, password):
                st.session_state.authenticated = True
                st.session_state.username = username
                st.session_state.role = get_user_role(username)
                st.rerun()
            else:
                st.error("Invalid username or password")

def signup_form():
    st.markdown("""
    <div style='padding: 0.5rem 0; margin-bottom: 1rem;'>
        <h3 style='font-size: 1.3rem; margin-bottom: 0.8rem; color: #BB86FC;'>✨ Create Account</h3>
        <p style='font-size: 0.9rem; opacity: 0.8; margin-bottom: 1rem;'>
            Please fill in the details to create a new account for the bank guidelines assistant.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    with st.form("signup_form"):
        username = st.text_input("Username", placeholder="Choose a username")
        password = st.text_input("Password", type="password", placeholder="Create a strong password")
        confirm_password = st.text_input("Confirm Password", type="password", placeholder="Repeat your password")
        
        submit_col1, submit_col2 = st.columns([3, 1])
        with submit_col1:
            submit = st.form_submit_button("✅ Create Account", use_container_width=True)
        
        if submit:
            if password != confirm_password:
                st.error("Passwords do not match")
            elif signup(username, password):
                st.success("Account created successfully. Please login.")
            else:
                st.error("Username already exists")

def chat_interface():
    # Chat header with bank logo and welcome message
    st.markdown("""
    <div style='display: flex; align-items: center; margin-bottom: 1.5rem;
               background: linear-gradient(90deg, rgba(156,39,176,0.1) 0%, rgba(66,39,90,0.05) 100%); 
               padding: 1rem; border-radius: 12px;'>
        <div>
            <h1 style='margin:0; font-size: 1.8rem; color: #BB86FC;'>Bank Guidelines & Principles Assistant</h1>
            <p style='margin:0.3rem 0 0 0; opacity: 0.7; font-size: 1rem;'>
                Ask me anything about banking regulations, policies, and best practices
            </p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Display empty state if no messages
    if not st.session_state.chat_history:
        st.markdown("""
        <div style='background-color: rgba(45, 45, 68, 0.5); 
                    padding: 2rem; border-radius: 15px; margin: 2rem 0; text-align: center;'>
            <img src="https://img.icons8.com/fluency/96/null/chatbot.png" style='width: 80px; margin-bottom: 1rem;'>
            <h3 style='color: #BB86FC; margin-bottom: 0.5rem;'>How can I help you today?</h3>
            <p style='opacity: 0.8; max-width: 500px; margin: 0 auto 1rem auto;'>
                I can provide information on banking guidelines, regulatory compliance, 
                policy frameworks, and best practices for financial institutions.
            </p>
            <div style='display: flex; flex-wrap: wrap; justify-content: center; gap: 0.5rem; max-width: 600px; margin: 0 auto;'>
                <div style='background-color: rgba(156, 39, 176, 0.1); 
                          padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.9rem;'>
                    What are KYC guidelines?
                </div>
                <div style='background-color: rgba(156, 39, 176, 0.1); 
                          padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.9rem;'>
                    Explain Basel III regulations
                </div>
                <div style='background-color: rgba(156, 39, 176, 0.1); 
                          padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.9rem;'>
                    Anti-money laundering policies
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    # Custom chat container
    chat_container = st.container()
    
    with chat_container:
        # Display chat history with enhanced styling
        for i, message in enumerate(st.session_state.chat_history):
            with st.chat_message(message["role"], avatar="🧑‍💼" if message["role"]=="user" else "🏦"):
                st.write(message["content"])
    
    # Footer with chat input
    st.markdown("<div style='margin-top: 2rem;'></div>", unsafe_allow_html=True)
    
    # Chat input with improved placeholder
    user_input = st.chat_input("Ask about banking regulations, compliance, policies, standards...", key="chat_input")
    if user_input:
        # Add user message to chat history
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        
        # Display user message
        with st.chat_message("user", avatar="🧑‍💼"):
            st.write(user_input)
        
        # Get bot response with a spinner and custom message
        with st.spinner("Guidelines Assistant is thinking..."):
            response = get_chatbot_response(user_input)
        
        # Add assistant response to chat history
        st.session_state.chat_history.append({"role": "assistant", "content": response})
        
        # Display assistant response
        with st.chat_message("assistant", avatar="🏦"):
            st.write(response)
        
        # Rerun to update UI
        st.rerun()

if __name__ == "__main__":
    main()
