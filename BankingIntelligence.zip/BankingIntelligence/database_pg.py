"""
PostgreSQL Database Module for Banking Chatbot
"""
import os
import json
import datetime
import time
import pandas as pd
from sqlalchemy import create_engine, Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from sqlalchemy.sql import func
from sqlalchemy import exc

# Get database connection URL from environment variable
DATABASE_URL = os.environ.get("DATABASE_URL")

# Create SQLAlchemy engine with connection pool settings
engine = create_engine(
    DATABASE_URL,
    pool_size=5,  # Maximum number of connections to keep in the pool
    max_overflow=10,  # Maximum number of connections to allow above pool_size
    pool_timeout=30,  # Seconds to wait before timing out on getting a connection
    pool_recycle=1800,  # Recycle connections after 30 minutes
    pool_pre_ping=True  # Enable connection health checks
)

# Create base class for SQLAlchemy models
Base = declarative_base()

class User(Base):
    """User model for authentication and user management."""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(100), nullable=False)
    role = Column(String(20), default='user')  # 'user', 'admin'
    created_at = Column(DateTime, default=func.now())
    last_login = Column(DateTime)
    
    # Relationships
    chat_histories = relationship("ChatHistory", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(username='{self.username}', role='{self.role}')>"
    
class ChatHistory(Base):
    """Chat history model for storing user conversations."""
    __tablename__ = 'chat_histories'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    timestamp = Column(DateTime, default=func.now())
    user_message = Column(Text, nullable=False)
    bot_response = Column(Text, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="chat_histories")
    
    def __repr__(self):
        return f"<ChatHistory(user_id={self.user_id}, timestamp='{self.timestamp}')>"

class Document(Base):
    """Document model for storing document information."""
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    file_type = Column(String(20), nullable=False)  # 'pdf', 'txt'
    uploaded_by = Column(Integer, ForeignKey('users.id'))
    upload_date = Column(DateTime, default=func.now())
    file_path = Column(String(255))
    content_chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Document(title='{self.title}', file_type='{self.file_type}')>"

class DocumentChunk(Base):
    """Document chunk model for storing document content chunks."""
    __tablename__ = 'document_chunks'
    
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey('documents.id'), nullable=False)
    content = Column(Text, nullable=False)
    order = Column(Integer, nullable=False)
    
    # Relationships
    document = relationship("Document", back_populates="content_chunks")
    
    def __repr__(self):
        return f"<DocumentChunk(document_id={self.document_id}, order={self.order})>"

# Create tables with retry mechanism
def create_tables():
    """Create all database tables if they don't exist with retry mechanism."""
    max_retries = 3
    retry_delay = 1  # seconds
    
    for attempt in range(max_retries):
        try:
            Base.metadata.create_all(engine)
            print("Successfully created database tables")
            return True
        except exc.OperationalError as e:
            if "SSL connection has been closed unexpectedly" in str(e) and attempt < max_retries - 1:
                print(f"Database connection error during table creation (attempt {attempt+1}/{max_retries}): {e}")
                time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                continue
            else:
                raise
        except Exception as e:
            print(f"Error creating tables: {e}")
            raise

# Create session factory with retries
Session = scoped_session(sessionmaker(bind=engine))

def get_db_session():
    """Get a new database session with retry mechanism."""
    max_retries = 3
    retry_delay = 1  # seconds
    
    for attempt in range(max_retries):
        try:
            # Create a fresh session
            session = Session()
            # Test the connection with a simple query
            session.execute("SELECT 1")
            return session
        except exc.OperationalError as e:
            if "SSL connection has been closed unexpectedly" in str(e) and attempt < max_retries - 1:
                print(f"Database connection error (attempt {attempt+1}/{max_retries}): {e}")
                time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                continue
            else:
                raise
        except Exception as e:
            raise

# User operations
def create_user(username, password_hash, role='user'):
    """Create a new user."""
    session = get_db_session()
    try:
        new_user = User(
            username=username,
            password_hash=password_hash,
            role=role,
            created_at=datetime.datetime.utcnow()
        )
        session.add(new_user)
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def get_user_by_username(username):
    """Get a user by username."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        return user
    except Exception as e:
        raise e
    finally:
        session.close()

def update_user_password(username, new_password_hash):
    """Update a user's password."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if user:
            user.password_hash = new_password_hash
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def update_user_role(username, new_role):
    """Update a user's role."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if user:
            user.role = new_role
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def update_user_last_login(username):
    """Update a user's last login time."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if user:
            user.last_login = datetime.datetime.utcnow()
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def delete_user_by_username(username):
    """Delete a user by username."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if user:
            session.delete(user)
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def list_all_users():
    """List all users."""
    session = get_db_session()
    try:
        users = session.query(User).all()
        return users
    except Exception as e:
        raise e
    finally:
        session.close()

# Chat history operations
def add_chat_message(username, user_message, bot_response):
    """Add a chat message to a user's chat history."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if not user:
            return False
        
        chat_entry = ChatHistory(
            user_id=user.id,
            timestamp=datetime.datetime.utcnow(),
            user_message=user_message,
            bot_response=bot_response
        )
        
        session.add(chat_entry)
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def get_chat_history(username, limit=50):
    """Get a user's chat history."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if not user:
            return []
        
        chat_history = session.query(ChatHistory)\
            .filter_by(user_id=user.id)\
            .order_by(ChatHistory.timestamp)\
            .limit(limit)\
            .all()
        
        # Convert to list of dict for easy use
        result = []
        for chat in chat_history:
            result.append({
                "user": chat.user_message,
                "bot": chat.bot_response,
                "timestamp": chat.timestamp
            })
        
        return result
    except Exception as e:
        raise e
    finally:
        session.close()

def clear_chat_history(username):
    """Clear a user's chat history."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=username).first()
        if not user:
            return False
        
        session.query(ChatHistory).filter_by(user_id=user.id).delete()
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

# Document operations
def add_document(title, description, file_type, uploaded_by_username, file_path):
    """Add a document to the database."""
    session = get_db_session()
    try:
        user = session.query(User).filter_by(username=uploaded_by_username).first()
        if not user:
            return None
        
        document = Document(
            title=title,
            description=description,
            file_type=file_type,
            uploaded_by=user.id,
            upload_date=datetime.datetime.utcnow(),
            file_path=file_path
        )
        
        session.add(document)
        session.commit()
        return document.id
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def add_document_chunk(document_id, content, order):
    """Add a document chunk to the database."""
    session = get_db_session()
    try:
        chunk = DocumentChunk(
            document_id=document_id,
            content=content,
            order=order
        )
        
        session.add(chunk)
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def get_document_by_id(document_id):
    """Get a document by ID."""
    session = get_db_session()
    try:
        document = session.query(Document).filter_by(id=document_id).first()
        return document
    except Exception as e:
        raise e
    finally:
        session.close()

def get_document_chunks(document_id):
    """Get all chunks for a document, ordered by their position."""
    session = get_db_session()
    try:
        chunks = session.query(DocumentChunk)\
            .filter_by(document_id=document_id)\
            .order_by(DocumentChunk.order)\
            .all()
        return chunks
    except Exception as e:
        raise e
    finally:
        session.close()

def list_documents():
    """List all documents."""
    session = get_db_session()
    try:
        documents = session.query(Document).all()
        return documents
    except Exception as e:
        raise e
    finally:
        session.close()

def delete_document(document_id):
    """Delete a document and all its chunks."""
    session = get_db_session()
    try:
        document = session.query(Document).filter_by(id=document_id).first()
        if document:
            session.delete(document)
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

# Statistics operations
def get_user_stats():
    """Get user statistics."""
    session = get_db_session()
    try:
        total_users = session.query(User).count()
        user_roles = session.query(User.role, func.count(User.id)).group_by(User.role).all()
        
        stats = {
            "total_users": total_users,
            "user_roles": {role: count for role, count in user_roles}
        }
        
        return stats
    except Exception as e:
        raise e
    finally:
        session.close()

def get_document_stats():
    """Get document statistics."""
    session = get_db_session()
    try:
        total_documents = session.query(Document).count()
        doc_types = session.query(Document.file_type, func.count(Document.id)).group_by(Document.file_type).all()
        
        stats = {
            "total_documents": total_documents,
            "document_types": {doc_type: count for doc_type, count in doc_types}
        }
        
        return stats
    except Exception as e:
        raise e
    finally:
        session.close()

def get_chat_stats():
    """Get chat statistics."""
    session = get_db_session()
    try:
        total_messages = session.query(ChatHistory).count()
        messages_per_user = session.query(
            User.username, 
            func.count(ChatHistory.id)
        ).join(ChatHistory).group_by(User.username).all()
        
        stats = {
            "total_messages": total_messages,
            "messages_per_user": {username: count for username, count in messages_per_user}
        }
        
        return stats
    except Exception as e:
        raise e
    finally:
        session.close()

def initialize_database():
    """Initialize the database by creating all tables."""
    create_tables()
    
    # Create admin user if no users exist
    session = get_db_session()
    try:
        user_count = session.query(User).count()
        if user_count == 0:
            # Import the hash_password function here to avoid circular imports
            from auth import hash_password
            admin_user = User(
                username="admin",
                password_hash=hash_password("admin123"),
                role="admin",
                created_at=datetime.datetime.utcnow()
            )
            session.add(admin_user)
            session.commit()
            print("Created admin user: admin/admin123")
    except Exception as e:
        session.rollback()
        print(f"Error creating admin user: {e}")
    finally:
        session.close()

# Migrate data from pickle files to database
def migrate_pickle_data():
    """Migrate data from pickle files to PostgreSQL database."""
    import pickle
    from auth import hash_password
    
    # Check if users pickle file exists
    if os.path.exists("data/users.pkl"):
        try:
            with open("data/users.pkl", "rb") as f:
                users = pickle.load(f)
                
            # Add users to database
            session = get_db_session()
            for username, user_data in users.items():
                # Check if user already exists
                existing_user = session.query(User).filter_by(username=username).first()
                if not existing_user:
                    new_user = User(
                        username=username,
                        password_hash=user_data.get("password"),  # Assuming password is already hashed
                        role=user_data.get("role", "user"),
                        created_at=datetime.datetime.utcnow()
                    )
                    session.add(new_user)
            
            session.commit()
            print("Migrated users from pickle file to database")
            session.close()
        except Exception as e:
            print(f"Error migrating users: {e}")

    # Check if chat histories pickle files exist
    if os.path.exists("data/chat_histories.pkl"):
        try:
            with open("data/chat_histories.pkl", "rb") as f:
                chat_histories = pickle.load(f)
                
            # Add chat histories to database
            for username, history in chat_histories.items():
                user = get_user_by_username(username)
                if user:
                    for message in history:
                        add_chat_message(
                            username=username,
                            user_message=message.get("user", ""),
                            bot_response=message.get("bot", "")
                        )
            
            print("Migrated chat histories from pickle file to database")
        except Exception as e:
            print(f"Error migrating chat histories: {e}")

    # Check if documents pickle file exists
    if os.path.exists("data/knowledge_base.pkl"):
        try:
            with open("data/knowledge_base.pkl", "rb") as f:
                documents = pickle.load(f)
                
            # Get admin user
            admin_user = get_user_by_username("admin")
                
            # Add documents to database
            for i, doc in enumerate(documents):
                doc_id = add_document(
                    title=f"Document {i+1}",
                    description=f"Migrated from knowledge base",
                    file_type="txt",
                    uploaded_by_username="admin",
                    file_path="data/knowledge_base.pkl"
                )
                
                if doc_id:
                    add_document_chunk(
                        document_id=doc_id,
                        content=doc["page_content"],
                        order=i
                    )
            
            print("Migrated documents from pickle file to database")
        except Exception as e:
            print(f"Error migrating documents: {e}")

# Test database connection with retry mechanism
def test_connection():
    """Test database connection with retry mechanism."""
    max_retries = 3
    retry_delay = 1  # seconds
    
    for attempt in range(max_retries):
        try:
            conn = engine.connect()
            conn.execute("SELECT 1")
            conn.close()
            return True
        except exc.OperationalError as e:
            if "SSL connection has been closed unexpectedly" in str(e) and attempt < max_retries - 1:
                print(f"Database connection error (attempt {attempt+1}/{max_retries}): {e}")
                time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                continue
            else:
                print(f"Database connection error: {e}")
                return False
        except Exception as e:
            print(f"Database connection error: {e}")
            return False

if __name__ == "__main__":
    # Test database connection
    if test_connection():
        print("Database connection successful")
        # Initialize database
        initialize_database()
        # Migrate data from pickle files to database
        migrate_pickle_data()
    else:
        print("Failed to connect to database")