import streamlit as st
import os
import re
import base64
from datetime import datetime

def format_time(timestamp=None):
    """Format a timestamp as a string."""
    if timestamp is None:
        timestamp = datetime.now()
    return timestamp.strftime("%Y-%m-%d %H:%M:%S")

def is_valid_email(email):
    """Check if a string is a valid email address."""
    email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(email_regex, email) is not None

def is_strong_password(password):
    """Check if a password is strong enough."""
    # At least 8 characters, 1 uppercase, 1 lowercase, 1 number
    if len(password) < 8:
        return False, "Password must be at least 8 characters long."
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter."
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter."
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number."
    return True, "Password is strong."

def sanitize_filename(filename):
    """Sanitize a filename to ensure it's safe to use."""
    # Remove any path components
    filename = os.path.basename(filename)
    # Replace any non-alphanumeric characters with underscores
    sanitized = re.sub(r'[^\w\.\-]', '_', filename)
    return sanitized

def truncate_text(text, max_length=100):
    """Truncate text to a maximum length."""
    if len(text) <= max_length:
        return text
    return text[:max_length] + "..."

def extract_keywords(text):
    """Extract keywords from text (simplified version).
    
    In a real implementation, you might use NLP techniques for better keyword extraction.
    """
    # Remove common stop words (simplified version)
    stop_words = {"a", "an", "the", "and", "or", "but", "is", "are", "was", "were", 
                 "in", "on", "at", "to", "for", "with", "by", "about", "of"}
    
    # Split text into words, convert to lowercase, and remove punctuation
    words = re.findall(r'\b\w+\b', text.lower())
    
    # Remove stop words
    keywords = [word for word in words if word not in stop_words and len(word) > 2]
    
    # Count frequency of each keyword
    keyword_freq = {}
    for word in keywords:
        if word in keyword_freq:
            keyword_freq[word] += 1
        else:
            keyword_freq[word] = 1
    
    # Return top 10 keywords by frequency
    sorted_keywords = sorted(keyword_freq.items(), key=lambda x: x[1], reverse=True)
    return [word for word, freq in sorted_keywords[:10]]

def format_currency(amount, currency="$"):
    """Format a number as currency."""
    return f"{currency}{amount:,.2f}"

def calculate_percentage(part, whole):
    """Calculate a percentage."""
    if whole == 0:
        return 0
    return (part / whole) * 100
