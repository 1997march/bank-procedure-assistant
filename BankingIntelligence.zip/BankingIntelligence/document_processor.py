import streamlit as st
import os
import tempfile
import pickle
from database_json import add_document, get_document_by_id, list_documents as list_db_documents
from chatbot import add_document_to_vector_store

# For handling PDF files
try:
    import PyPDF2
except ImportError:
    st.error("PyPDF2 is not installed. PDF processing will not work.")

def extract_text_from_pdf(file_path):
    """Extract text from a PDF file."""
    text = ""
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text += page.extract_text() + "\n\n"
        return text
    except Exception as e:
        st.error(f"Error extracting text from PDF: {str(e)}")
        raise

def upload_document(file, file_type, description, admin_username):
    """Upload a document to the system."""
    if not file:
        return False, "No file selected"
    
    try:
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as temp_file:
            temp_file.write(file.getvalue())
            temp_path = temp_file.name
        
        # Extract text based on file type
        if file_type == "pdf":
            try:
                text = extract_text_from_pdf(temp_path)
            except Exception as e:
                os.unlink(temp_path)
                return False, f"Error processing PDF: {str(e)}"
        elif file_type == "txt":
            try:
                with open(temp_path, 'r', encoding='utf-8', errors='replace') as f:
                    text = f.read()
            except Exception as e:
                os.unlink(temp_path)
                return False, f"Error processing text file: {str(e)}"
        else:
            os.unlink(temp_path)
            return False, "Unsupported file type. Only PDF and TXT files are supported."
        
        # Add document to vector store
        metadata = {
            "source": file.name,
            "description": description,
            "uploaded_by": admin_username,
            "file_type": file_type
        }
        
        chunks_added = add_document_to_vector_store(text, metadata)
        
        # Save document record to JSON database
        file_path = f"data/documents/{file.name}"
        
        # Create documents directory if it doesn't exist
        os.makedirs("data/documents", exist_ok=True)
        
        # Save the file
        with open(file_path, 'wb') as f:
            f.write(file.getvalue())
            
        # Add document to database
        document_id = add_document(
            title=file.name,
            description=description,
            file_type=file_type,
            uploaded_by_username=admin_username,
            file_path=file_path
        )
        
        # Clean up
        os.unlink(temp_path)
        
        return True, f"Document uploaded successfully. Added {chunks_added} chunks to the knowledge base."
    
    except Exception as e:
        return False, f"Error processing document: {str(e)}"

def list_documents():
    """List all uploaded documents."""
    documents = list_db_documents()
    return [
        {
            "filename": doc.get("title", "Unknown"),
            "description": doc.get("description", ""),
            "uploaded_by": doc.get("uploaded_by_username", "unknown"),
            "file_type": doc.get("file_type", "unknown"),
            "document_id": doc.get("id", 0)
        }
        for doc in documents
    ]

def delete_document(document_id):
    """Delete a document from the list.
    
    Note: This only removes it from the document list, not from the vector store.
    To completely remove it from the vector store, you would need to rebuild the vector store
    without the deleted document, which is more complex.
    """
    from database_json import delete_document as delete_db_document
    
    # Get document before deletion to get the name
    document = get_document_by_id(document_id)
    if not document:
        return False, "Document not found."
    
    # Delete the document
    success = delete_db_document(document_id)
    if success:
        return True, f"Document '{document.get('title', 'Unknown')}' removed from the list."
    
    return False, "Failed to delete document."

def get_document_stats():
    """Get statistics about uploaded documents."""
    documents = list_db_documents()
    
    stats = {
        "total_documents": len(documents),
        "total_chunks": 0,  # We don't track chunks separately in the JSON DB
        "by_file_type": {},
        "by_uploader": {}
    }
    
    # Count by file type
    for doc in documents:
        file_type = doc.get("file_type", "unknown")
        if file_type not in stats["by_file_type"]:
            stats["by_file_type"][file_type] = 0
        stats["by_file_type"][file_type] += 1
        
        # Count by uploader
        uploader = doc.get("uploaded_by_username", "unknown")
        if uploader not in stats["by_uploader"]:
            stats["by_uploader"][uploader] = 0
        stats["by_uploader"][uploader] += 1
    
    return stats
