"""
Initialize the PostgreSQL database for Banking Chatbot
"""
import os
import sys
import streamlit as st
from database_pg import (
    test_connection, 
    initialize_database,
    migrate_pickle_data
)

def main():
    """Initialize the database and migrate data from pickle files."""
    print("Testing database connection...")
    if test_connection():
        print("Database connection successful")
        
        print("Initializing database...")
        initialize_database()
        
        print("Migrating data from pickle files...")
        migrate_pickle_data()
        
        print("Database initialization complete")
        return True
    else:
        print("Failed to connect to database")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)