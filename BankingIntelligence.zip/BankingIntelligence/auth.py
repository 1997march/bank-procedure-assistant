import streamlit as st
import hashlib
import os
import datetime
from database_json import (
    get_user_by_username, create_user, update_user_password, 
    update_user_role, delete_user_by_username, list_all_users,
    update_user_last_login
)

def hash_password(password):
    """Hash a password for storing."""
    return hashlib.sha256(password.encode()).hexdigest()

def create_admin_if_not_exists():
    """Create an admin user if no users exist."""
    try:
        # Check if admin user exists
        admin_user = get_user_by_username("admin")
        
        # If admin doesn't exist, create one
        if not admin_user:
            admin_username = "admin"
            admin_password = "admin123"  # Default password, should be changed
            
            success = create_user(
                username=admin_username,
                password_hash=hash_password(admin_password),
                role="admin"
            )
            
            if success:
                st.warning("Default admin account created. Username: admin, Password: admin123. Please change the password.")
        
    except Exception as e:
        st.error(f"Error initializing user database: {str(e)}")

def signup(username, password, role="user"):
    """Create a new user account with specified role (default: user)."""
    try:
        # Check if username already exists
        existing_user = get_user_by_username(username)
        if existing_user:
            return False
        
        # Create new user with specified role
        success = create_user(
            username=username,
            password_hash=hash_password(password),
            role=role
        )
        
        return success
    except Exception as e:
        st.error(f"Error creating user: {str(e)}")
        return False

def login(username, password):
    """Authenticate a user."""
    try:
        # Get user by username
        user = get_user_by_username(username)
        
        # Check if user exists and password is correct
        if user and user["password_hash"] == hash_password(password):
            # Update last login time
            update_user_last_login(username)
            return True
        
        return False
    except Exception as e:
        st.error(f"Error logging in: {str(e)}")
        return False

def logout():
    """Log out the current user."""
    st.session_state.authenticated = False
    st.session_state.username = None
    st.session_state.role = None
    st.session_state.chat_history = []

def is_authenticated():
    """Check if a user is authenticated."""
    return st.session_state.authenticated

def get_user_role(username):
    """Get the role of a user."""
    try:
        # Get user by username
        user = get_user_by_username(username)
        
        if user:
            return user["role"]
        
        return None
    except Exception as e:
        st.error(f"Error getting user role: {str(e)}")
        return None

def change_password(username, current_password, new_password):
    """Change a user's password."""
    try:
        # Get user by username
        user = get_user_by_username(username)
        
        # Check if user exists and current password is correct
        if user and user["password_hash"] == hash_password(current_password):
            # Update password
            success = update_user_password(username, hash_password(new_password))
            return success
        
        return False
    except Exception as e:
        st.error(f"Error changing password: {str(e)}")
        return False

def change_user_role(username, new_role, admin_username):
    """Change a user's role. Only admins can do this."""
    try:
        # Get admin user
        admin_user = get_user_by_username(admin_username)
        
        # Check if admin_username is an admin
        if admin_user and admin_user["role"] == "admin":
            # Get user to update
            user = get_user_by_username(username)
            
            if user:
                # Update user role
                success = update_user_role(username, new_role)
                return success
        
        return False
    except Exception as e:
        st.error(f"Error changing user role: {str(e)}")
        return False

def delete_user(username, admin_username):
    """Delete a user. Only admins can do this."""
    try:
        # Get admin user
        admin_user = get_user_by_username(admin_username)
        
        # Check if admin_username is an admin
        if admin_user and admin_user["role"] == "admin":
            # Prevent admin from deleting themselves
            if username != admin_username:
                # Delete user
                success = delete_user_by_username(username)
                return success
        
        return False
    except Exception as e:
        st.error(f"Error deleting user: {str(e)}")
        return False

def list_users(admin_username):
    """List all users. Only admins can do this."""
    try:
        # Get admin user
        admin_user = get_user_by_username(admin_username)
        
        # Check if admin_username is an admin
        if admin_user and admin_user["role"] == "admin":
            # Get all users
            users = list_all_users()
            
            # Convert to list of dictionaries
            user_list = [{
                "username": user["username"],
                "role": user["role"]
            } for user in users]
            
            return user_list
        
        return []
    except Exception as e:
        st.error(f"Error listing users: {str(e)}")
        return []
