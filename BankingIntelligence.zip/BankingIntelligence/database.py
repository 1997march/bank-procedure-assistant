import os
import pickle
import json

# Ensure data directory exists
os.makedirs("data", exist_ok=True)

def initialize_database():
    """Initialize the database files if they don't exist."""
    try:
        # Try to load the files to check integrity
        load_users()
        load_chat_history_all()
        load_documents()
    except (FileNotFoundError, EOFError, pickle.UnpicklingError):
        # If any file is corrupted or missing, recreate all
        reset_database()

def reset_database():
    """Reset all database files to their initial state."""
    # Create users with admin account
    admin_user = {
        "admin": {
            "username": "admin",
            "password": "admin123",  # This will be hashed in auth.py
            "role": "admin"
        }
    }
    save_users(admin_user)
    
    # Create empty chat history
    save_chat_history_all({})
    
    # Create empty documents list
    save_documents([])

def load_users():
    """Load the users database."""
    try:
        with open("data/users.pkl", "rb") as f:
            return pickle.load(f)
    except (FileNotFoundError, EOFError):
        return {}

def save_users(users):
    """Save the users database."""
    with open("data/users.pkl", "wb") as f:
        pickle.dump(users, f)

def load_chat_history_all():
    """Load all chat histories."""
    try:
        with open("data/chat_history.pkl", "rb") as f:
            return pickle.load(f)
    except (FileNotFoundError, EOFError):
        return {}

def save_chat_history_all(chat_histories):
    """Save all chat histories."""
    with open("data/chat_history.pkl", "wb") as f:
        pickle.dump(chat_histories, f)

def load_chat_history(username):
    """Load chat history for a specific user."""
    chat_histories = load_chat_history_all()
    return chat_histories.get(username, [])

def save_chat_history(username, chat_history):
    """Save chat history for a specific user."""
    chat_histories = load_chat_history_all()
    chat_histories[username] = chat_history
    save_chat_history_all(chat_histories)

def load_documents():
    """Load the documents database."""
    try:
        with open("data/documents.pkl", "rb") as f:
            return pickle.load(f)
    except (FileNotFoundError, EOFError):
        return []

def save_documents(documents):
    """Save the documents database."""
    with open("data/documents.pkl", "wb") as f:
        pickle.dump(documents, f)

def get_user_stats():
    """Get user statistics."""
    users = load_users()
    chat_histories = load_chat_history_all()
    
    stats = {
        "total_users": len(users),
        "users_by_role": {},
        "users_with_chat_history": len(chat_histories),
        "total_messages": sum(len(history) for history in chat_histories.values())
    }
    
    # Count users by role
    for user in users.values():
        role = user.get("role", "unknown")
        if role not in stats["users_by_role"]:
            stats["users_by_role"][role] = 0
        stats["users_by_role"][role] += 1
    
    return stats

def backup_database():
    """Backup the database to JSON files."""
    # Backup users
    users = load_users()
    with open("data/users_backup.json", "w") as f:
        json.dump(users, f, indent=4)
    
    # Backup chat histories
    chat_histories = load_chat_history_all()
    with open("data/chat_history_backup.json", "w") as f:
        json.dump(chat_histories, f, indent=4)
    
    # Backup documents
    documents = load_documents()
    with open("data/documents_backup.json", "w") as f:
        json.dump(documents, f, indent=4)
    
    return True
