"""
JSON File-based Database Module for Banking Chatbot
"""
import os
import json
import datetime
import uuid
import time
from pathlib import Path

# Ensure data directory exists
DATA_DIR = "data"
Path(DATA_DIR).mkdir(exist_ok=True)

# File paths for storing data
USERS_FILE = os.path.join(DATA_DIR, "users.json")
CHAT_HISTORY_FILE = os.path.join(DATA_DIR, "chat_history.json")
DOCUMENTS_FILE = os.path.join(DATA_DIR, "documents.json")
DOCUMENT_CHUNKS_FILE = os.path.join(DATA_DIR, "document_chunks.json")

# Default data structures
DEFAULT_USERS = {}
DEFAULT_CHAT_HISTORY = {}
DEFAULT_DOCUMENTS = []
DEFAULT_DOCUMENT_CHUNKS = []

def _ensure_file_exists(file_path, default_data):
    """Ensure a file exists with default data."""
    if not os.path.exists(file_path):
        with open(file_path, "w") as f:
            json.dump(default_data, f)
    return True

def _load_json(file_path, default_data):
    """Load data from a JSON file with retry mechanism."""
    _ensure_file_exists(file_path, default_data)
    
    max_retries = 3
    retry_delay = 0.5  # seconds
    
    for attempt in range(max_retries):
        try:
            with open(file_path, "r") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            # If JSON is invalid, restore from default
            if attempt == max_retries - 1:
                print(f"Error loading {file_path}: {e}. Restoring default.")
                with open(file_path, "w") as f:
                    json.dump(default_data, f)
                return default_data
            time.sleep(retry_delay)
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            return default_data

def _save_json(file_path, data):
    """Save data to a JSON file with retry mechanism."""
    max_retries = 3
    retry_delay = 0.5  # seconds
    
    # Create a temporary file first to avoid corruption
    temp_file = f"{file_path}.tmp"
    
    for attempt in range(max_retries):
        try:
            with open(temp_file, "w") as f:
                json.dump(data, f, indent=2, default=str)
            
            # Atomically replace the original file (as atomic as Python allows)
            if os.path.exists(file_path):
                os.replace(temp_file, file_path)
            else:
                os.rename(temp_file, file_path)
            return True
        except Exception as e:
            print(f"Error saving {file_path} (attempt {attempt+1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
    
    return False

# USER OPERATIONS

def create_user(username, password_hash, role="user"):
    """Create a new user."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    
    if username in users:
        return False
    
    users[username] = {
        "id": str(uuid.uuid4()),
        "username": username,
        "password_hash": password_hash,
        "role": role,
        "created_at": datetime.datetime.utcnow().isoformat(),
        "last_login": None
    }
    
    return _save_json(USERS_FILE, users)

def get_user_by_username(username):
    """Get a user by username."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    return users.get(username)

def update_user_password(username, new_password_hash):
    """Update a user's password."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    
    if username not in users:
        return False
    
    users[username]["password_hash"] = new_password_hash
    return _save_json(USERS_FILE, users)

def update_user_role(username, new_role):
    """Update a user's role."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    
    if username not in users:
        return False
    
    users[username]["role"] = new_role
    return _save_json(USERS_FILE, users)

def update_user_last_login(username):
    """Update a user's last login time."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    
    if username not in users:
        return False
    
    users[username]["last_login"] = datetime.datetime.utcnow().isoformat()
    return _save_json(USERS_FILE, users)

def delete_user_by_username(username):
    """Delete a user by username."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    
    if username not in users:
        return False
    
    del users[username]
    
    # Also delete chat history
    clear_chat_history(username)
    
    return _save_json(USERS_FILE, users)

def list_all_users():
    """List all users."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    return [user for user in users.values()]

# CHAT HISTORY OPERATIONS

def add_chat_message(username, user_message, bot_response):
    """Add a chat message to a user's chat history."""
    chat_history = _load_json(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
    
    if username not in chat_history:
        chat_history[username] = []
    
    chat_entry = {
        "id": str(uuid.uuid4()),
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "user": user_message,
        "bot": bot_response
    }
    
    chat_history[username].append(chat_entry)
    return _save_json(CHAT_HISTORY_FILE, chat_history)

def get_chat_history(username, limit=50):
    """Get a user's chat history."""
    chat_history = _load_json(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
    
    if username not in chat_history:
        return []
    
    # Return most recent messages first, up to the limit
    return chat_history[username][-limit:]

def clear_chat_history(username):
    """Clear a user's chat history."""
    chat_history = _load_json(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
    
    if username not in chat_history:
        return True
    
    chat_history[username] = []
    return _save_json(CHAT_HISTORY_FILE, chat_history)

# DOCUMENT OPERATIONS

def add_document(title, description, file_type, uploaded_by_username, file_path):
    """Add a document to the database."""
    documents = _load_json(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
    
    document = {
        "id": str(uuid.uuid4()),
        "title": title,
        "description": description,
        "file_type": file_type,
        "uploaded_by": uploaded_by_username,
        "upload_date": datetime.datetime.utcnow().isoformat(),
        "file_path": file_path
    }
    
    documents.append(document)
    _save_json(DOCUMENTS_FILE, documents)
    
    return document["id"]

def add_document_chunk(document_id, content, order):
    """Add a document chunk to the database."""
    document_chunks = _load_json(DOCUMENT_CHUNKS_FILE, DEFAULT_DOCUMENT_CHUNKS)
    
    chunk = {
        "id": str(uuid.uuid4()),
        "document_id": document_id,
        "content": content,
        "order": order
    }
    
    document_chunks.append(chunk)
    return _save_json(DOCUMENT_CHUNKS_FILE, document_chunks)

def get_document_by_id(document_id):
    """Get a document by ID."""
    documents = _load_json(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
    
    for doc in documents:
        if doc["id"] == document_id:
            return doc
    
    return None

def get_document_chunks(document_id):
    """Get all chunks for a document, ordered by their position."""
    document_chunks = _load_json(DOCUMENT_CHUNKS_FILE, DEFAULT_DOCUMENT_CHUNKS)
    
    # Filter chunks for this document and sort by order
    chunks = [chunk for chunk in document_chunks if chunk["document_id"] == document_id]
    chunks.sort(key=lambda x: x["order"])
    
    return chunks

def list_documents():
    """List all documents."""
    return _load_json(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)

def delete_document(document_id):
    """Delete a document and all its chunks."""
    documents = _load_json(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
    document_chunks = _load_json(DOCUMENT_CHUNKS_FILE, DEFAULT_DOCUMENT_CHUNKS)
    
    # Filter out the document to delete
    new_documents = [doc for doc in documents if doc["id"] != document_id]
    
    # Filter out chunks for this document
    new_chunks = [chunk for chunk in document_chunks if chunk["document_id"] != document_id]
    
    doc_saved = _save_json(DOCUMENTS_FILE, new_documents)
    chunks_saved = _save_json(DOCUMENT_CHUNKS_FILE, new_chunks)
    
    return doc_saved and chunks_saved

# STATISTICS OPERATIONS

def get_user_stats():
    """Get user statistics."""
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    
    total_users = len(users)
    user_roles = {}
    
    for user in users.values():
        role = user.get("role", "user")
        if role in user_roles:
            user_roles[role] += 1
        else:
            user_roles[role] = 1
    
    return {
        "total_users": total_users,
        "user_roles": user_roles
    }

def get_document_stats():
    """Get document statistics."""
    documents = _load_json(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
    
    total_documents = len(documents)
    document_types = {}
    
    for doc in documents:
        file_type = doc.get("file_type", "unknown")
        if file_type in document_types:
            document_types[file_type] += 1
        else:
            document_types[file_type] = 1
    
    return {
        "total_documents": total_documents,
        "document_types": document_types
    }

def get_chat_stats():
    """Get chat statistics."""
    chat_history = _load_json(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
    
    total_messages = sum(len(messages) for messages in chat_history.values())
    messages_per_user = {username: len(messages) for username, messages in chat_history.items()}
    
    return {
        "total_messages": total_messages,
        "messages_per_user": messages_per_user
    }

def initialize_database():
    """Initialize the database by creating all necessary files."""
    # Ensure all data files exist
    _ensure_file_exists(USERS_FILE, DEFAULT_USERS)
    _ensure_file_exists(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
    _ensure_file_exists(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
    _ensure_file_exists(DOCUMENT_CHUNKS_FILE, DEFAULT_DOCUMENT_CHUNKS)
    
    # Create admin user if no users exist
    users = _load_json(USERS_FILE, DEFAULT_USERS)
    if not users:
        # Import the hash_password function here to avoid circular imports
        from auth import hash_password
        create_user("admin", hash_password("admin123"), "admin")
        print("Created admin user: admin/admin123")
    
    return True

def migrate_from_pickle():
    """Migrate data from pickle files if they exist."""
    import pickle
    from auth import hash_password
    
    # Migrate users
    if os.path.exists("data/users.pkl"):
        try:
            with open("data/users.pkl", "rb") as f:
                users = pickle.load(f)
                
            for username, user_data in users.items():
                create_user(
                    username=username,
                    password_hash=user_data.get("password"),  # Assuming password is already hashed
                    role=user_data.get("role", "user")
                )
            
            print("Migrated users from pickle file to JSON database")
        except Exception as e:
            print(f"Error migrating users: {e}")
    
    # Migrate chat histories
    if os.path.exists("data/chat_histories.pkl"):
        try:
            with open("data/chat_histories.pkl", "rb") as f:
                chat_histories = pickle.load(f)
                
            for username, history in chat_histories.items():
                for message in history:
                    add_chat_message(
                        username=username,
                        user_message=message.get("user", ""),
                        bot_response=message.get("bot", "")
                    )
            
            print("Migrated chat histories from pickle file to JSON database")
        except Exception as e:
            print(f"Error migrating chat histories: {e}")
    
    # Migrate knowledge base
    if os.path.exists("data/knowledge_base.pkl"):
        try:
            with open("data/knowledge_base.pkl", "rb") as f:
                documents = pickle.load(f)
                
            for i, doc in enumerate(documents):
                doc_id = add_document(
                    title=f"Document {i+1}",
                    description=f"Migrated from knowledge base",
                    file_type="txt",
                    uploaded_by_username="admin",
                    file_path="data/knowledge_base.pkl"
                )
                
                if doc_id:
                    add_document_chunk(
                        document_id=doc_id,
                        content=doc["page_content"],
                        order=i
                    )
            
            print("Migrated documents from pickle file to JSON database")
        except Exception as e:
            print(f"Error migrating documents: {e}")
    
    return True

def test_database():
    """Test if the JSON database is working properly."""
    try:
        # Check if we can read/write to all files
        _ensure_file_exists(USERS_FILE, DEFAULT_USERS)
        _ensure_file_exists(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
        _ensure_file_exists(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
        _ensure_file_exists(DOCUMENT_CHUNKS_FILE, DEFAULT_DOCUMENT_CHUNKS)
        
        # Try to load data
        _load_json(USERS_FILE, DEFAULT_USERS)
        _load_json(CHAT_HISTORY_FILE, DEFAULT_CHAT_HISTORY)
        _load_json(DOCUMENTS_FILE, DEFAULT_DOCUMENTS)
        _load_json(DOCUMENT_CHUNKS_FILE, DEFAULT_DOCUMENT_CHUNKS)
        
        return True
    except Exception as e:
        print(f"Database test failed: {e}")
        return False

if __name__ == "__main__":
    # Test database
    if test_database():
        print("JSON database working properly")
        
        # Initialize database
        initialize_database()
        
        # Migrate data from pickle files
        migrate_from_pickle()
    else:
        print("JSON database test failed")